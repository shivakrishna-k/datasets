# expedITion_codify_challenge_July2021
For our July 2021 expedITion Codify Challenge, this is our data &amp; code base to start from.
